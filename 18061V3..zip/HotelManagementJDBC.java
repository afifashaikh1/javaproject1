import java.sql.*;
import java.util.Scanner;

class Customer {
    int customerId;
    String name;
    String contact;

    public Customer(String name, String contact) {
        this.name = name;
        this.contact = contact;
    }
}

class Hotel {
    private Connection connection;

    public Hotel() {
        try {
            // Establish database connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3308/hotel_management", "root", "");
        } catch (SQLException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void checkIn(int roomNumber, Customer customer) {
        try {
            // Check if the room is available
            PreparedStatement checkRoomStmt = connection.prepareStatement("SELECT customer_id FROM rooms WHERE room_number = ?");
            checkRoomStmt.setInt(1, roomNumber);
            ResultSet rs = checkRoomStmt.executeQuery();
            if (rs.next() && rs.getInt("customer_id") != 0) {
                System.out.println("Room " + roomNumber + " is already occupied.");
                return;
            }

            // Insert customer into customers table
            PreparedStatement insertCustomerStmt = connection.prepareStatement(
                "INSERT INTO customers (name, contact) VALUES (?, ?)", Statement.RETURN_GENERATED_KEYS);
            insertCustomerStmt.setString(1, customer.name);
            insertCustomerStmt.setString(2, customer.contact);
            insertCustomerStmt.executeUpdate();

            // Get generated customer ID
            ResultSet generatedKeys = insertCustomerStmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                customer.customerId = generatedKeys.getInt(1);
            }

            // Assign customer to room
            PreparedStatement assignRoomStmt = connection.prepareStatement(
                "UPDATE rooms SET customer_id = ? WHERE room_number = ?");
            assignRoomStmt.setInt(1, customer.customerId);
            assignRoomStmt.setInt(2, roomNumber);
            assignRoomStmt.executeUpdate();

            System.out.println("Customer checked in successfully to room " + roomNumber);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void checkOut(int roomNumber) {
        try {
            // Check if the room is occupied
            PreparedStatement checkRoomStmt = connection.prepareStatement("SELECT customer_id FROM rooms WHERE room_number = ?");
            checkRoomStmt.setInt(1, roomNumber);
            ResultSet rs = checkRoomStmt.executeQuery();
            if (rs.next() && rs.getInt("customer_id") == 0) {
                System.out.println("Room " + roomNumber + " is already empty.");
                return;
            }

            int customerId = rs.getInt("customer_id");

            // Remove customer from room
            PreparedStatement freeRoomStmt = connection.prepareStatement("UPDATE rooms SET customer_id = NULL WHERE room_number = ?");
            freeRoomStmt.setInt(1, roomNumber);
            freeRoomStmt.executeUpdate();

            // Delete customer from customers table
            PreparedStatement deleteCustomerStmt = connection.prepareStatement("DELETE FROM customers WHERE customer_id = ?");
            deleteCustomerStmt.setInt(1, customerId);
            deleteCustomerStmt.executeUpdate();

            System.out.println("Customer checked out successfully from room " + roomNumber);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void displayRooms() {
        try {
            PreparedStatement stmt = connection.prepareStatement(
                "SELECT r.room_number, c.name, c.contact FROM rooms r LEFT JOIN customers c ON r.customer_id = c.customer_id");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int roomNumber = rs.getInt("room_number");
                String customerName = rs.getString("name");
                String customerContact = rs.getString("contact");

                if (customerName == null) {
                    System.out.println("Room " + roomNumber + " is available.");
                } else {
                    System.out.println("Room " + roomNumber + " is occupied by Name: " + customerName + ", Contact: " + customerContact);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

public class HotelManagementJDBC {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Hotel hotel = new Hotel();
        boolean running = true;

        while (running) {
            System.out.println("\nHotel Management System");
            System.out.println("1. Check In");
            System.out.println("2. Check Out");
            System.out.println("3. Display Rooms");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter room number (1-100): ");
                    int roomNumber = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    if (roomNumber < 1 || roomNumber > 100) {
                        System.out.println("Invalid room number. Please choose between 1 and 100.");
                        break;
                    }
                    System.out.print("Enter customer name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter customer contact: ");
                    String contact = scanner.nextLine();
                    Customer customer = new Customer(name, contact);
                    hotel.checkIn(roomNumber, customer);
                    break;
                case 2:
                    System.out.print("Enter room number (1-100) to check out: ");
                    roomNumber = scanner.nextInt();
                    if (roomNumber < 1 || roomNumber > 100) {
                        System.out.println("Invalid room number. Please choose between 1 and 100.");
                        break;
                    }
                    hotel.checkOut(roomNumber);
                    break;
                case 3:
                    hotel.displayRooms();
                    break;
                case 4:
                    running = false;
                    System.out.println("Exiting Hotel Management System.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}